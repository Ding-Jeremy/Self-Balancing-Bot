\babel@toc {french}{}\relax 
\babel@toc {french}{}\relax 
